

public class Fox extends Predator {

    public Fox(boolean status, PenguinFamily penguinFamily) {
        super(status, penguinFamily);
    }


    @Override
    public void updateKilledPenguinFamily() {

        int killedPossibility = killedPosibility();

        if (killedPossibility == 1)
            killPenguin(getPenguinFamily());
        else if (killedPossibility == 2)
            killChicks(getPenguinFamily());
        else if (killedPossibility == 3)
            killEggs(getPenguinFamily());

        getPenguinFamily().updateChicksAndEggsBaseParents();

    }

    private int killedPosibility() {
        int posibility = 0;
        if (getDogNumber() == 0)
            posibility = getRandom(1, 15);
        else if (getDogNumber() == 1)
            posibility = getRandom(1, 10);
        else if (getDogNumber() == 2)
            posibility = getRandom(1, 8);

        return posibility;
    }

    private int getRandom(int min, int max) {
        return randomNumber.genRandom(min, max);
    }

    private boolean isPosibility() {
        int min = 0;
        int max = 0;
        int maxRandomRange = 0;
        int dogsNumber = getDogNumber();

        if (dogsNumber == 0) {
            min = 1;
            max = 8;
            maxRandomRange = 100;
        } else if (dogsNumber == 1) {
            min = 1;
            max = 2;
            maxRandomRange = 100;
        } else if (dogsNumber == 2) {
            min = 1;
            max = 8;
            maxRandomRange = 1000;
        }

        int possibility = getRandom(1, maxRandomRange);
        return possibility >= min && possibility <= max;
    }

    private void killPenguin(PenguinFamily penguinFamily) {

        if (!penguinFamily.isFemaleKilled() && isPosibility()) {
            penguinFamily.killFemale();
            setKilledFemalePenguinCount(getKilledFemalePenguinCount() + 1);
        }

        if (!penguinFamily.isMaleKilled() && isPosibility()) {
            penguinFamily.killMale();
            setKilledMalePenguinCount(getKilledMalePenguinCount() + 1);
        }

    }

    private void killChicks(PenguinFamily penguinFamily) {

        for (Chick chick : penguinFamily.getChicks()) {
            if (!isPosibility()) continue;
            if (!chick.isStatus()) continue;
            chick.setStatus(false);
            setKilledChicksCount(getKilledChicksCount() + 1);
        }
    }

    private void killEggs(PenguinFamily penguinFamily) {

        for (Egg egg : penguinFamily.getEggs()) {
            if (!isPosibility()) continue;
            if (!egg.isStatus()) continue;
            egg.setStatus(false);
            setKilledEggCount(getKilledEggCount() + 1);
        }
    }

}
