public class Simulation {
    private Input input;
    private ColonyFiling colonyFiling;
    private ColonySimulationData colonySimulationData;
    private ColonyEvent colonyEvent;
    private ColonySummary colonySummary;
    private ColonyEvaluate colonyEvaluate;

    public Simulation() {
        input = new Input();
        colonyFiling = new ColonyFiling();
        colonySimulationData = new ColonySimulationData();
        colonyEvent = new ColonyEvent();
        colonySummary = new ColonySummary();
        colonyEvaluate=new ColonyEvaluate();
    }

    public static void main(String[] args) {
        Simulation simulation = new Simulation();
        simulation.startColonySimulation();
    }

    public void showColonySummary() {
        try {
            String content = "";

            displayMessage("End of simulation summary:");
            displayMessage("      " + "complete family: " + colonySimulationData.getCompleteFamilyCount());
            displayMessage("      " + "live penguins: " + colonySimulationData.getLivePenguinsCount());
            displayMessage("      " + "live chicks: " + colonySimulationData.getLiveChickCount());
            displayMessage("Simulation is Done.");
            requestEnterKey();

            colonySummary.finalCalculate();

            displayMessage("Colony survival rates:");
            displayMessage("      " + "* " + "family group survival rate: " + colonySimulationData.getFamilyGroupSurvivalRate() + "%");
            displayMessage("      " + "* " + "penguin survival rate: " + colonySimulationData.getPenguinSurvivalRate() + "%");
            displayMessage("      " + "* " + "egg survival rate: " + colonySimulationData.getEggSurvivalRate() + "%");
            displayMessage("      " + "* " + "chick survival rate: " + colonySimulationData.getChickSurvivalRate() + "%");
            displayMessage("      " + "* " + "colony survival: " + colonySimulationData.getOverallColonySurvival() + "%");

            content = content + colonySimulationData.getFamilyGroupSurvivalRate() + ",";
            content += colonySimulationData.getPenguinSurvivalRate() + ",";
            content += colonySimulationData.getEggSurvivalRate() + ",";
            content += colonySimulationData.getChickSurvivalRate() + ",";
            content += colonySimulationData.getOverallColonySurvival();

            colonyFiling.writeFinalColony(content);
            displayMessage("Writing survival rates into colonyFinal.txt");
            displayMessage("Goodbye");

        } catch (Exception ex) {
            System.out.println("Error exists in colony summary");
        }
    }

    public void startColonySimulation() {
        int monthNumber = 7;

        try {
            colonySimulationData = colonyFiling.getColony();

            displayWelcomeMassage();
            requestPawPatrolDogsNumber();
            displayMessage("Running simulation from month 7 to 6 ");
            displayMessage("      " + "Number of dogs :" + colonySimulationData.getDogsNumber());

            for (int i = 1; i <= 12; i++) {
                colonySimulationData = colonyEvaluate.resetColonyData(colonySimulationData);
                colonySimulationData.setMonthNumber(monthNumber);

                displayMessage("Simulating month " + colonySimulationData.getMonthNumber());

                for (PenguinFamily penguinFamily : colonySimulationData.getPenguinFamilies()) {

                    colonySimulationData.setPenguinFamily(penguinFamily);
                    if (!colonyEvaluate.isExistPenguinFamily(colonySimulationData)) continue;

                    colonyEvent.setColonyMode(new Laying());
                    colonyEvent.setColonySimulationData(colonySimulationData);
                    colonyEvent.checkChange();
                    colonySimulationData = colonyEvent.getColonySimulationData();

                    colonyEvent.setColonySimulationData(colonySimulationData);
                    colonyEvent.setColonyMode(new LayHatching());
                    colonyEvent.checkChange();
                    colonySimulationData = colonyEvent.getColonySimulationData();

                    colonyEvent.setColonyMode(new ColonyHunting());
                    colonyEvent.setColonySimulationData(colonySimulationData);
                    colonyEvent.checkChange();
                    colonySimulationData = colonyEvent.getColonySimulationData();

                    colonySimulationData = colonyEvaluate.evaluateCompleteFamily(colonySimulationData);

                    colonyEvent.setColonyMode(new ColonyGrowing());
                    colonyEvent.setColonySimulationData(colonySimulationData);
                    colonyEvent.checkChange();
                    colonySimulationData = colonyEvent.getColonySimulationData();

                    if (i == 12)
                    {
                        colonySummary.setColonySimulationData(colonySimulationData);
                        colonySummary.calculatePerFamily();
                    }
                }

                colonyEvent.setColonySimulationData(colonySimulationData);
                colonyEvent.setColonyMode(new DogProtecting());
                colonyEvent.checkChange();
                colonySimulationData = colonyEvent.getColonySimulationData();

                colonySummary.setColonySimulationData(colonySimulationData);
                colonySummary.calculatePerMonth();

                displayMessage("       " + "+ new chicks:" + colonySimulationData.getNewChicks());
                displayMessage("       " + "+ new eggs:" + colonySimulationData.getNewEggs());
                displayMessage("       " + "- penguin killed: " + colonySimulationData.getKilledmalePenguinCount() + " male,"
                        + colonySimulationData.getKilledfemalePenguinCount() + " female");
                displayMessage("       " + "- chicks killed: " + colonySimulationData.getKilledChicks());
                displayMessage("       " + "- eggs eaten: " + colonySimulationData.getKilledEggs());
                displayMessage("       " + "- fox killed: " + colonySimulationData.getTotalKilledFoxes());
                displayMessage("       " + "- cat killed: " + colonySimulationData.getTotalKilledCats());
                displayMessage("  End of month colony status:");
                displayMessage("       " + "complete Family: " + colonySimulationData.getCompleteFamilyCount());
                displayMessage("       " + "live chick count: " + colonySimulationData.getLiveChickCount());
                displayMessage("       " + "uneaten egg count: " + colonySimulationData.getUneatenEggCount());
                displayMessage("       " + "fox count: " + colonySimulationData.getFoxCount());
                displayMessage("       " + "cat count: " + colonySimulationData.getCatCount());
                displayMessage("       " + "shark count: " + colonySimulationData.getSharkCount());

                if (monthNumber == 12)
                    monthNumber = 1;
                else
                    ++monthNumber;

                if (monthNumber == 7)
                    showColonySummary();
                else
                    requestEnterKey();
            }

        } catch (
                Exception ex) {
            System.out.println("Program is stopped");
            System.out.println("Error is :" + ex.getMessage());
        }

    }

    public void requestEnterKey() {
        input.acceptEnter("press ENTER to continue ");
    }

    public void requestPawPatrolDogsNumber() {

        String dogsNumber = input.acceptStringInput("How many Patrol Dogs? (0-2) ");
        while (!checkValidation(dogsNumber)) {
            dogsNumber = input.acceptStringInput("How many Patrol Dogs? (0-2) ");
        }

        colonySimulationData.setDogsNumber(Integer.parseInt(dogsNumber));
    }

    public boolean checkValidation(String input) {
        Validation validation = new Validation();

        if (validation.isBlank(input) || validation.checkAlphabetic(input)
                || validation.checkDogNumberValidation(Integer.parseInt(input)))
            return false;

        return true;
    }

    public void displayWelcomeMassage() {
        System.out.println("Welcome to Paw Patrol");
        System.out.println("================");
    }

    public void displayMessage(String message) {
        System.out.println(message);
    }


}
