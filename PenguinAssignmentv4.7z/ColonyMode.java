public abstract class ColonyMode {
    private ColonySimulationData colonySimulationData;

    public ColonySimulationData getColonySimulationData() {
        return colonySimulationData;
    }

    public void setColonySimulationData(ColonySimulationData colonySimulationData) {
        if (colonySimulationData!=null)
        this.colonySimulationData = colonySimulationData;
    }

    public abstract void checkChange();
}
