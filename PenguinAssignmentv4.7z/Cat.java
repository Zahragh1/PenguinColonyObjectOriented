
public class Cat extends Predator {


    public Cat(boolean status, PenguinFamily penguinFamily) {
        super(status, penguinFamily);
    }

    @Override
    public void updateKilledPenguinFamily() {

        int killedPossibility = killedPosibility();

        if (killedPossibility == 1)
            killPenguin(getPenguinFamily());
        else if (killedPossibility == 2)
            killChicks(getPenguinFamily());

        getPenguinFamily().updateChicksAndEggsBaseParents();

    }

    private int killedPosibility() {
        int posibility = 0;
        if (getDogNumber() == 0)
            posibility = getRandom(1, 13);
        else if (getDogNumber() == 1)
            posibility = getRandom(1, 8);
        else if (getDogNumber() == 2)
            posibility = getRandom(1, 6);

        return posibility;

    }

    private int getRandom(int min, int max) {
        return randomNumber.genRandom(min, max);
    }

    private boolean isPosibility() {
        int min = 0;
        int max = 0;
        int maxRandomRange = 0;
        int dogsNumber = getDogNumber();

        if (dogsNumber == 0) {
            min = 1;
            max = 4;
            maxRandomRange = 100;
        } else if (dogsNumber == 1) {
            min = 1;
            max = 1;
            maxRandomRange = 100;
        } else if (dogsNumber == 2) {
            min = 1;
            max = 4;
            maxRandomRange = 1000;
        }

        int possibility = getRandom(1, maxRandomRange);
        return possibility >= min && possibility <= max;
    }

    private void killPenguin(PenguinFamily penguinFamily) {

        if (!penguinFamily.isFemaleKilled() && isPosibility()) {
            penguinFamily.killFemale();
            setKilledFemalePenguinCount(getKilledFemalePenguinCount() + 1);
        }

        if (!penguinFamily.isMaleKilled() && isPosibility()) {
            penguinFamily.killMale();
            setKilledMalePenguinCount(getKilledMalePenguinCount() + 1);
        }

    }


    private void killChicks(PenguinFamily penguinFamily) {

        for (Chick chick : penguinFamily.getChicks()) {
            if (!isPosibility()) continue;
            if (!chick.isStatus()) continue;
            chick.setStatus(false);
            setKilledChicksCount(getKilledChicksCount() + 1);
        }
    }
}
