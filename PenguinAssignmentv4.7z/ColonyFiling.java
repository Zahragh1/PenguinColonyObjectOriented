public class ColonyFiling {

    private FileHandling fileHandling;
    private ColonySimulationData data;
    private String inputFileName = "Colony.txt";
    private String outputFileName = "ColonyFinal.txt";


    public ColonyFiling() {
        this.fileHandling = new FileHandling();
        this.data = new ColonySimulationData();
    }

    public ColonySimulationData getColony() {
        String[] content = fileHandling.readFile(inputFileName).split(",");

        if (content.toString().equals("")) return data;

        data.setPenguinFamilyCountAtStart(Integer.parseInt(content[0]));
        data.setFoxCount(Integer.parseInt(content[1]));
        data.setCatCount(Integer.parseInt(content[2]));
        data.setSharkCount(Integer.parseInt(content[3]));

        generatePenguinFamily();

        return data;
    }

    public void writeFinalColony(String content) {
        fileHandling.writeFile(outputFileName, content);
    }

    private void generatePenguinFamily() {
        for (int i = 0; i < data.getPenguinFamilyCountAtStart(); i++)
            data.addPenguinFamily(new PenguinFamily());

    }
}
