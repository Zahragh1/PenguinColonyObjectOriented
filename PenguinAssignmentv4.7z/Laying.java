public class Laying extends ColonyMode {
    @Override
    public void checkChange() {

        getColonySimulationData().setNewEggs(getColonySimulationData().getNewEggs()
                + getColonySimulationData().getPenguinFamily().checkForNewEgg(getColonySimulationData().getMonthNumber()));

    }
}
