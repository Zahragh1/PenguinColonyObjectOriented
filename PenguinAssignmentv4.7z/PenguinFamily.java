import java.util.ArrayList;
import java.util.ListIterator;


public class PenguinFamily {

    private String uniqueId ;
    private Penguin malePenguin;
    private Penguin femalePenguin;
    private ArrayList<Chick> chicks;
    private ArrayList<Egg> eggs;
    private static int id;

    public PenguinFamily() {
        malePenguin = new Penguin();
        malePenguin.setFlag(false);
        malePenguin.setStatus(true);
        femalePenguin = new Penguin();
        femalePenguin.setFlag(true);
        femalePenguin.setStatus(true);
        chicks = new ArrayList<>();
        eggs = new ArrayList<>();
        ++id;
        uniqueId = "P" + id;
    }

    public PenguinFamily(Penguin female, Penguin male) {

        if (female == null)
            throw new IllegalArgumentException("Female should initialize");

        if (male == null)
            throw new IllegalArgumentException("Male Should initialize");

        ++id;
        this.uniqueId = "P" + id;
        this.femalePenguin = female;
        this.malePenguin = male;
        this.chicks = new ArrayList<>();
        this.eggs = new ArrayList<>();

    }

    public void updateChicksAgePerMonth() {

        for (Chick chick : chicks) {
            if (chick.isStatus())
                chick.setAge(chick.getAge() + 1);
        }
    }

    public void updateEggsAgePerMonth() {
        for (Egg egg : eggs) {
            if (egg.isStatus())
                egg.setAge(egg.getAge() + 1);
        }
    }

    private int updateForHatchedEggsForOneMonthAge() {
        RandomNumber randomNumber = new RandomNumber();
        int newChick = 0;
        ListIterator<Egg> iter = eggs.listIterator();

        while (iter.hasNext()) {
            if (iter.next().getAge() == 1) {
                int possibility = randomNumber.genRandom(1, 10);
                if (possibility >= 1 && possibility <= 7) {
                    ++newChick;
                    chicks.add(new Chick(0, true));

                }
                iter.remove();
            }
        }

        return newChick;
    }

    public void updateChicksAndEggsBaseParents() {

        if (isFemaleKilled() && isMaleKilled()) {
            for (Chick chick : chicks)
                chick.setStatus(false);

            for (Egg egg : eggs)
                egg.setStatus(false);

        }
    }

    /**
     * Generate new eggs
     *
     * @return lay number as integer.
     */
    private int updateEggsBasePenguinLayPerMonth(int monthNumber) {
        int newEggs = 0;
        if (monthNumber > 2 && monthNumber < 8) return newEggs;
        if (femalePenguin.isStatus() && malePenguin.isStatus()) {
            newEggs = femalePenguin.lay();
            for (int i = 0; i < newEggs; i++)
                eggs.add(new Egg(0, true));

        }

        return newEggs;
    }

    public int checkForNewChicks() {
        return updateForHatchedEggsForOneMonthAge();
    }

    public int checkForNewEgg(int monthNumber) {
        return updateEggsBasePenguinLayPerMonth(monthNumber);
    }


    public int getAliveEggsCount() {
        int count = 0;
        for (Egg egg : eggs)
            if (egg.isStatus()) ++count;

        return count;
    }

    public int getAliveChicksCount() {
        int count = 0;
        for (Chick chick : chicks)
            if (chick.isStatus()) ++count;

        return count;
    }

    public boolean isPenguinFamilyAlive() {
        if (isMaleKilled() && isFemaleKilled() &&
                getAliveEggsCount() == 0 && getAliveChicksCount() == 0
        )
            return false;
        else
            return true;
    }

    public boolean isCompleteFamily() {
        return getFemalePenguin().isStatus() && getMalePenguin().isStatus();
    }

    public int getLivePenguinsCount() {
        int penguinCount = 0;
        if (getMalePenguin().isStatus()) ++penguinCount;
        if (getFemalePenguin().isStatus()) ++penguinCount;
        return penguinCount;
    }


    public boolean isMaleKilled() {
        return !malePenguin.isStatus();
    }

    public boolean isFemaleKilled() {
        return !femalePenguin.isStatus();
    }

    public void killMale() {
        malePenguin.setStatus(false);
    }

    public void killFemale() {
        femalePenguin.setStatus(false);
    }

    public Penguin getMalePenguin() {
        return malePenguin;
    }

    public void setMalePenguin(Penguin malePenguin) {
        if (malePenguin != null)
            this.malePenguin = malePenguin;
    }

    public Penguin getFemalePenguin() {

        return femalePenguin;
    }

    public void setFemalePenguin(Penguin femalePenguin) {
        if (femalePenguin != null)
            this.femalePenguin = femalePenguin;
    }

    public ArrayList<Chick> getChicks() {
        return chicks;
    }

    public void setChick(Chick chick) {
        if (chick != null)
            chicks.add(chick);
    }

    public ArrayList<Egg> getEggs() {
        return eggs;
    }

    public void setEgg(Egg egg) {
        if (egg != null)
            eggs.add(egg);
    }


}
