public class ColonySummary {

    private ColonySimulationData colonySimulationData;

    public ColonySimulationData getColonySimulationData() {
        return colonySimulationData;
    }

    public void setColonySimulationData(ColonySimulationData colonySimulationData) {
        if (colonySimulationData != null)
            this.colonySimulationData = colonySimulationData;
    }

    public void calculatePerMonth() {

        getColonySimulationData().setTotalHatchedEggs(getColonySimulationData().getTotalHatchedEggs()
                + getColonySimulationData().getNewChicks());

        getColonySimulationData().setTotalLaidEggs(getColonySimulationData().getTotalLaidEggs()
                + getColonySimulationData().getNewEggs());

    }

    public void calculatePerFamily()
    {

        getColonySimulationData().setLivePenguinsCount(
                getColonySimulationData().getLivePenguinsCount()
                        + getColonySimulationData().getPenguinFamily().getLivePenguinsCount());
    }

    public void finalCalculate() {

        getColonySimulationData().setFamilyGroupSurvivalRate(((double) getColonySimulationData().getCompleteFamilyCount()
                / getColonySimulationData().getPenguinFamilyCountAtStart()) * 100);

        getColonySimulationData().setPenguinSurvivalRate(((double) getColonySimulationData().getLivePenguinsCount()
                / (getColonySimulationData().getPenguinFamilyCountAtStart() * 2)) * 100);

        getColonySimulationData().setEggSurvivalRate(((double) getColonySimulationData().getTotalHatchedEggs() / getColonySimulationData().getTotalLaidEggs()) * 100);

        getColonySimulationData().setChickSurvivalRate(((double) getColonySimulationData().getLiveChickCount() / getColonySimulationData().getTotalHatchedEggs()) * 100);

        getColonySimulationData().setOverallColonySurvival(((double) (getColonySimulationData().getLivePenguinsCount() + getColonySimulationData().getLiveChickCount()) / (getColonySimulationData().getPenguinFamilyCountAtStart() * 2)));

    }


}
