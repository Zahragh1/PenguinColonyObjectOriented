import java.util.ArrayList;

public class ColonySimulationData {
    private int foxCount;
    private int catCount;
    private int sharkCount;
    private int killedmalePenguinCount = 0;
    private int killedfemalePenguinCount = 0;
    private int killedChicks = 0;
    private int killedEggs = 0;
    private int penguinFamilyCountAtStart;
    private int newEggs;
    private int newChicks;
    private int completeFamilyCount;
    private int liveChickCount;
    private int uneatenEggCount;
    private int livePenguinsCount;
    private int totalLaidEggs;
    private int totalHatchedEggs;
    private int totalKilledFoxes;
    private int totalKilledCats;
    private int killedFoxes;
    private int killedCats;
    private int dogsNumber;
    private PenguinFamily penguinFamily;
    private int monthNumber;
    private ArrayList<PenguinFamily> penguinFamilies;
    private double familyGroupSurvivalRate;
    private double penguinSurvivalRate;
    private double eggSurvivalRate;
    private double chickSurvivalRate;
    private double overallColonySurvival;


    public ColonySimulationData() {
        dogsNumber = 0;
        killedCats = 0;
        killedFoxes = 0;
        foxCount = 0;
        catCount = 0;
        sharkCount = 0;
        penguinFamilyCountAtStart = 0;
        newEggs = 0;
        newChicks = 0;
        completeFamilyCount = 0;
        liveChickCount = 0;
        uneatenEggCount = 0;
        livePenguinsCount = 0;
        totalLaidEggs = 0;
        totalHatchedEggs = 0;
        totalKilledFoxes = 0;
        totalKilledCats = 0;
        penguinFamily = new PenguinFamily();
        penguinFamilies = new ArrayList<>();
        familyGroupSurvivalRate = 0;
        penguinSurvivalRate = 0;
        eggSurvivalRate = 0;
        chickSurvivalRate = 0;
        overallColonySurvival = 0;
    }

    public double getFamilyGroupSurvivalRate() {
        return familyGroupSurvivalRate;
    }

    public void setFamilyGroupSurvivalRate(double familyGroupSurvivalRate) {
        this.familyGroupSurvivalRate = familyGroupSurvivalRate;
    }

    public double getPenguinSurvivalRate() {
        return penguinSurvivalRate;
    }

    public void setPenguinSurvivalRate(double penguinSurvivalRate) {
        this.penguinSurvivalRate = penguinSurvivalRate;
    }

    public double getEggSurvivalRate() {
        return eggSurvivalRate;
    }

    public void setEggSurvivalRate(double eggSurvivalRate) {
        this.eggSurvivalRate = eggSurvivalRate;
    }

    public double getChickSurvivalRate() {
        return chickSurvivalRate;
    }

    public void setChickSurvivalRate(double chickSurvivalRate) {
        this.chickSurvivalRate = chickSurvivalRate;
    }

    public double getOverallColonySurvival() {
        return overallColonySurvival;
    }

    public void setOverallColonySurvival(double overallColonySurvival) {
        this.overallColonySurvival = overallColonySurvival;
    }

    public PenguinFamily getPenguinFamily() {
        return penguinFamily;
    }

    public int getTotalKilledFoxes() {
        return totalKilledFoxes;
    }

    public void setTotalKilledFoxes(int totalKilledFoxes) {
        if (totalKilledFoxes >= 0)
            this.totalKilledFoxes = totalKilledFoxes;
    }

    public int getTotalKilledCats() {
        return totalKilledCats;
    }

    public void setTotalKilledCats(int totalKilledCats) {
        if (totalKilledCats >= 0)
            this.totalKilledCats = totalKilledCats;
    }


    public int getTotalLaidEggs() {
        return totalLaidEggs;
    }

    public void setTotalLaidEggs(int totalLaidEggs) {
        if (totalLaidEggs >= 0)
            this.totalLaidEggs = totalLaidEggs;
    }

    public int getTotalHatchedEggs() {
        return totalHatchedEggs;
    }

    public void setTotalHatchedEggs(int totalHatchedEggs) {
        if (totalHatchedEggs >= 0)
            this.totalHatchedEggs = totalHatchedEggs;
    }

    public int getLivePenguinsCount() {
        return livePenguinsCount;
    }

    public void setLivePenguinsCount(int livePenguinsCount) {
        if (livePenguinsCount >= 0)
            this.livePenguinsCount = livePenguinsCount;
    }

    public int getNewEggs() {
        return newEggs;
    }

    public void setNewEggs(int newEggs) {
        if (newEggs >= 0)
            this.newEggs = newEggs;
    }

    public int getNewChicks() {
        return newChicks;
    }

    public void setNewChicks(int newChicks) {
        if (newChicks >= 0)
            this.newChicks = newChicks;
    }

    public int getCompleteFamilyCount() {
        return completeFamilyCount;
    }

    public void setCompleteFamilyCount(int completeFamilyCount) {
        if (completeFamilyCount >= 0)
            this.completeFamilyCount = completeFamilyCount;
    }

    public int getLiveChickCount() {
        return liveChickCount;
    }

    public void setLiveChickCount(int liveChickCount) {
        if (liveChickCount >= 0)
            this.liveChickCount = liveChickCount;
    }

    public int getUneatenEggCount() {
        return uneatenEggCount;
    }

    public void setUneatenEggCount(int uneatenEggCount) {
        if (uneatenEggCount >= 0)
            this.uneatenEggCount = uneatenEggCount;
    }

    public int getDogsNumber() {
        return dogsNumber;
    }

    public int getKilledmalePenguinCount() {
        return killedmalePenguinCount;
    }

    public void setKilledmalePenguinCount(int killedmalePenguinCount) {
        if (killedmalePenguinCount >= 0)
            this.killedmalePenguinCount = killedmalePenguinCount;
    }

    public int getKilledfemalePenguinCount() {
        return killedfemalePenguinCount;
    }

    public void setKilledfemalePenguinCount(int killedfemalePenguinCount) {
        if (killedfemalePenguinCount >= 0)
            this.killedfemalePenguinCount = killedfemalePenguinCount;
    }

    public int getKilledChicks() {
        return killedChicks;
    }

    public void setKilledChicks(int killedChicks) {
        if (killedChicks >= 0)
            this.killedChicks = killedChicks;
    }

    public int getKilledEggs() {
        return killedEggs;
    }

    public void setKilledEggs(int killedEggs) {
        if (killedEggs >= 0)
            this.killedEggs = killedEggs;
    }

    public void setDogsNumber(int dogsNumber) {
        if (dogsNumber >= 0 && dogsNumber <= 2)
            this.dogsNumber = dogsNumber;
    }

    public int getKilledFoxes() {
        return killedFoxes;
    }

    public void setKilledFoxes(int killedFoxes) {
        if (killedFoxes >= 0)
            this.killedFoxes = killedFoxes;
    }

    public int getKilledCats() {
        return killedCats;
    }

    public void setKilledCats(int killedCats) {
        if (killedCats >= 0)
            this.killedCats = killedCats;
    }

    public int getFoxCount() {
        return foxCount;
    }

    public void setFoxCount(int foxCount) {
        if (foxCount >= 0)
            this.foxCount = foxCount;
    }

    public int getCatCount() {
        return catCount;
    }

    public void setCatCount(int catCount) {
        if (catCount >= 0)
            this.catCount = catCount;
    }

    public int getSharkCount() {
        return sharkCount;
    }

    public void setSharkCount(int sharkCount) {
        if (sharkCount >= 0)
            this.sharkCount = sharkCount;
    }

    public int getPenguinFamilyCountAtStart() {
        return penguinFamilyCountAtStart;
    }

    public void setPenguinFamilyCountAtStart(int penguinFamilyCountAtStart) {
        if (penguinFamilyCountAtStart >= 0)
            this.penguinFamilyCountAtStart = penguinFamilyCountAtStart;
    }

    public int getMonthNumber() {
        return monthNumber;
    }

    public void setMonthNumber(int monthNumber) {
        if (monthNumber >= 1 && monthNumber <= 12)
            this.monthNumber = monthNumber;
    }

    public ArrayList<PenguinFamily> getPenguinFamilies() {
        return penguinFamilies;
    }

    public void setPenguinFamilies(ArrayList<PenguinFamily> penguinFamilies) {
        this.penguinFamilies = penguinFamilies;
    }

    public void addPenguinFamily(PenguinFamily penguinFamily) {
        if (penguinFamily != null)
            penguinFamilies.add(penguinFamily);
    }

    public void setPenguinFamily(PenguinFamily penguinFamily) {
        if (penguinFamily != null)
            this.penguinFamily = penguinFamily;
    }
}
