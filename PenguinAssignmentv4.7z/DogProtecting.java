public class DogProtecting extends ColonyMode {

    @Override
    public void checkChange() {
        for (int dog = 0; dog < getColonySimulationData().getDogsNumber(); ++dog) {
            resetKilledPredators();
            updatePredators();

            getColonySimulationData().setTotalKilledFoxes(getColonySimulationData().getTotalKilledFoxes()
                    + getColonySimulationData().getKilledFoxes());
            getColonySimulationData().setTotalKilledCats(getColonySimulationData().getTotalKilledCats()
                    + getColonySimulationData().getKilledCats());
            getColonySimulationData().setFoxCount(getColonySimulationData().getFoxCount()
                    - getColonySimulationData().getKilledFoxes());
            getColonySimulationData().setCatCount(getColonySimulationData().getCatCount()
                    - getColonySimulationData().getKilledCats());
        }
    }

    private int getRandom(int min, int max) {
        RandomNumber randomNumber = new RandomNumber();
        return randomNumber.genRandom(min, max);
    }

    private void updatePredators() {

        int killedPosibility = getRandom(1, 2);

        if (killedPosibility == 1)
            for (int i = 0; i < getColonySimulationData().getFoxCount(); ++i) {
                if (!isPosibility()) continue;
                getColonySimulationData().setKilledFoxes(getColonySimulationData().getKilledFoxes() + 1);
            }

        else if (killedPosibility == 2)
            for (int i = 0; i < getColonySimulationData().getCatCount(); ++i) {
                if (!isPosibility()) continue;
                getColonySimulationData().setKilledCats(getColonySimulationData().getKilledCats() + 1);
            }
    }

    private boolean isPosibility() {
        int min = 0;
        int max = 0;
        int maxRandomRange = 0;

        if (getColonySimulationData().getDogsNumber() == 1) {
            min = 1;
            max = 1;
            maxRandomRange = 100;
        } else if (getColonySimulationData().getDogsNumber() == 2) {
            min = 1;
            max = 1;
            maxRandomRange = 10;
        }

        int possibility = getRandom(1, maxRandomRange);
        return possibility >= min && possibility <= max;
    }

    private void resetKilledPredators() {
        getColonySimulationData().setKilledFoxes(0);
        getColonySimulationData().setKilledCats(0);
    }
}
