

public class Penguin {


    /**
     * @variable flag    false:male true:female.
     */
    boolean flag;

    /**
     * @variable status    false:dead true:alive.
     */
    boolean status;

    public Penguin() {
        flag = false;
        status = false;
    }

    public Penguin(boolean flag, boolean status) {
        this.flag = flag;
        this.status = status;
    }

    public boolean isFlag() {
        return flag;
    }

    public void setFlag(boolean flag) {
        this.flag = flag;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }


    public int lay() {

        RandomNumber number = new RandomNumber();
        return number.genRandom(0, 2);

    }
}
