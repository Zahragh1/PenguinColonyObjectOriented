public class Egg {

    private int age;
    private boolean status;

    public Egg() {
        age = 0;
        status = false;
    }

    public Egg(int age, boolean status) {
        if (age < 0)
            throw new IllegalArgumentException("age shuldn t be negative");
        this.age = age;
        this.status = status;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        if (age >= 0)
            this.age = age;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }
}
