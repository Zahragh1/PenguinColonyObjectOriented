
public class ColonyEvent {
    private ColonyMode colonyMode;
    private ColonySimulationData colonySimulationData;

    public ColonyEvent() {

        this.colonyMode = new Laying();
        colonySimulationData = new ColonySimulationData();
    }

    public void checkChange() {
        colonyMode.setColonySimulationData(colonySimulationData);
        colonyMode.checkChange();
    }

    public void setColonyMode(ColonyMode colonyMode) {
        if (colonyMode != null)
            this.colonyMode = colonyMode;
    }

    public void setColonySimulationData(ColonySimulationData colonySimulationData) {
        if (colonySimulationData != null)
            this.colonySimulationData = colonySimulationData;
    }

    public ColonySimulationData getColonySimulationData() {

        return colonyMode.getColonySimulationData();
    }

}
