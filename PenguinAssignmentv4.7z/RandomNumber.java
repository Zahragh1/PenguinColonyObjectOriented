public class RandomNumber {

    public RandomNumber()
    {
    }
    /**
     * Generate a random number within the range.
     * @param   min    accepts the minimum range of number as integer.
     * @param   max    accpets the maximun range of number as integer.
     *
     * @return         A random number as integer.
     */
    public int genRandom(int min, int max)
    {
        return (int)(Math.random()*(max-min+1)+min);
    }
}
