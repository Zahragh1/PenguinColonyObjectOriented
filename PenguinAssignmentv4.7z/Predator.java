
public abstract class Predator {

    private int killedMalePenguinCount;
    private int killedFemalePenguinCount;
    private int killedChicksCount;
    private int killedEggCount;
    private boolean status;
    private PenguinFamily penguinFamily;
    private int dogNumber;

   protected RandomNumber randomNumber = new RandomNumber();


    public Predator(boolean status, PenguinFamily penguinFamily) {

        if (penguinFamily == null)
            throw new IllegalArgumentException("penguinFamily Should initialize");


        this.status = status;
        this.penguinFamily = penguinFamily;
        killedChicksCount = 0;
        killedFemalePenguinCount = 0;
        killedMalePenguinCount = 0;
        killedEggCount = 0;

    }

    public Predator() {

        penguinFamily = new PenguinFamily();
        status = false;
        killedChicksCount = 0;
        killedFemalePenguinCount = 0;
        killedMalePenguinCount = 0;
        killedEggCount = 0;
    }

    public int getKilledMalePenguinCount() {
        return killedMalePenguinCount;
    }

    public void setKilledMalePenguinCount(int killedMalePenguinCount) {
        if (killedMalePenguinCount > 0)
            this.killedMalePenguinCount = killedMalePenguinCount;
    }

    public int getKilledFemalePenguinCount() {
        return killedFemalePenguinCount;
    }

    public void setKilledFemalePenguinCount(int killedFemalePenguinCount) {
        if (killedFemalePenguinCount > 0)
            this.killedFemalePenguinCount = killedFemalePenguinCount;
    }

    public int getKilledChicksCount() {
        return killedChicksCount;
    }

    public void setKilledChicksCount(int killedChicksCount) {
        if (killedChicksCount > 0)
            this.killedChicksCount = killedChicksCount;
    }

    public int getKilledEggCount() {
        return killedEggCount;
    }

    public void setKilledEggCount(int killedEggCount) {
        if (killedEggCount > 0)
            this.killedEggCount = killedEggCount;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public PenguinFamily getPenguinFamily() {
        return penguinFamily;
    }

    public void setPenguinFamily(PenguinFamily penguinFamily) {
        if (penguinFamily != null)
            this.penguinFamily = penguinFamily;
    }

    public int getDogNumber() {
        return dogNumber;
    }

    public void setDogNumber(int dogNumber) {
        if (dogNumber >= 0 && dogNumber <= 2)
            this.dogNumber = dogNumber;
    }

    public abstract void updateKilledPenguinFamily();


}
