public class Validation {

    public boolean checkDogNumberValidation(int dogNumber) {
        if (dogNumber == 0 || dogNumber == 1 || dogNumber == 2)
            return false;

        System.out.println("Error: number not in range: 0 to 2 ");
        return true;
    }


    //methods checks if the string is empty or not.
    public boolean isBlank(String temp) {
        if (temp.trim().length() == 0) {
            System.out.println("Error : value is not a number:");
            return true;
        }

        return false;
    }

    public boolean checkAlphabetic(String name) {
        for (int i = 0; i < name.length(); i++) {
            char c = name.charAt(i);
            if (Character.isAlphabetic(c)) {
                System.out.println("Error : value is not a number:" + name);
                return true;
            }
        }
        return false;
    }
}
