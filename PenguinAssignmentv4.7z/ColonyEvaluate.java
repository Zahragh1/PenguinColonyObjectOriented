public class ColonyEvaluate {

    public ColonySimulationData resetColonyData(ColonySimulationData data)
    {
        data.setNewEggs(0);
        data.setNewChicks(0);
        data.setCompleteFamilyCount(0);
        data.setLiveChickCount(0);
        data.setUneatenEggCount(0);
        data.setKilledmalePenguinCount(0);
        data.setKilledfemalePenguinCount(0);
        data.setKilledChicks(0);
        data.setKilledEggs(0);
        data.setTotalKilledCats(0);
        data.setTotalKilledFoxes(0);

        return data;
    }

    public boolean isExistPenguinFamily(ColonySimulationData data)
    {
        if (data.getPenguinFamily().isPenguinFamilyAlive())
            return true;

        return false;
    }

    public ColonySimulationData evaluateCompleteFamily(ColonySimulationData data)
    {
        if (data.getPenguinFamily().isCompleteFamily())
            data.setCompleteFamilyCount(
                    data.getCompleteFamilyCount()+1
            );

        data.setUneatenEggCount(data.getUneatenEggCount()
                + data.getPenguinFamily().getAliveEggsCount());

        data.setLiveChickCount(data.getLiveChickCount()
                + data.getPenguinFamily().getAliveChicksCount());

        return data;

    }
}
