public class LayHatching extends ColonyMode {
    @Override
    public void checkChange() {

       getColonySimulationData().setNewChicks(getColonySimulationData().getNewChicks()
               + getColonySimulationData().getPenguinFamily().checkForNewChicks());

    }
}
