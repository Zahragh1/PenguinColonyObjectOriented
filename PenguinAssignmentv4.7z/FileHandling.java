import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class FileHandling {

    public FileHandling() {
    }

    /**
     * This method read the information in the file
     *
     * @param fileName A String which holds name of the File
     * @return An Arraylist of the String which hold the data in the file
     */
    public String readFile(String fileName) {
        String data = "";
        try {
            File myObj = new File(fileName);
            Scanner myReader = new Scanner(myObj);
            data = myReader.nextLine();
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
        return data;
    }


    public void writeFile(String file, String content) {
        try {
            PrintWriter writer = new PrintWriter(file);
            try {
                writer.println(content);
            } finally {
                try {
                    writer.close();
                } catch (Exception e) {
                    System.out.println("Error in closing file! Exiting...");
                }
            }
        } catch (Exception e) {
            System.out.println("Error in writing to file! Exiting...");
        }
    }
}
