public class ColonyGrowing extends ColonyMode {

    @Override
    public void checkChange() {
        getColonySimulationData().getPenguinFamily().updateChicksAgePerMonth();
        getColonySimulationData().getPenguinFamily().updateEggsAgePerMonth();

    }
}
