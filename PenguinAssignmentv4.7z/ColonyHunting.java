public class ColonyHunting extends ColonyMode {
    @Override
    public void checkChange() {

        for (int fCount = 0; fCount < getColonySimulationData().getFoxCount(); fCount++) {

            Fox fox = new Fox(true, getColonySimulationData().getPenguinFamily());
            fox.setDogNumber(getColonySimulationData().getDogsNumber());
            fox.updateKilledPenguinFamily();

            setKilledPenguinFamily(fox);
        }

        for (int cCount = 0; cCount < getColonySimulationData().getCatCount(); cCount++) {
            Cat cat = new Cat(true, getColonySimulationData().getPenguinFamily());
            cat.setDogNumber(getColonySimulationData().getDogsNumber());
            cat.updateKilledPenguinFamily();

            setKilledPenguinFamily(cat);
        }

        for (int sCount = 0; sCount < getColonySimulationData().getSharkCount(); sCount++) {
            Shark shark = new Shark(true, getColonySimulationData().getPenguinFamily());
            shark.updateKilledPenguinFamily();

            setKilledPenguinFamily(shark);
        }
    }

    private void setKilledPenguinFamily(Predator predator) {
        getColonySimulationData().setKilledmalePenguinCount(
                getColonySimulationData().getKilledmalePenguinCount() + predator.getKilledMalePenguinCount()
        );
        getColonySimulationData().setKilledfemalePenguinCount(
                getColonySimulationData().getKilledfemalePenguinCount() + predator.getKilledFemalePenguinCount()
        );
        getColonySimulationData().setKilledChicks(getColonySimulationData().getKilledChicks() +
                predator.getKilledChicksCount());

        getColonySimulationData().setKilledEggs(
                getColonySimulationData().getKilledEggs() + predator.getKilledEggCount()
        );

    }
}
