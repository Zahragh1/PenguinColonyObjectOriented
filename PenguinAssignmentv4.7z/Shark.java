
public class Shark extends Predator {


    public Shark(boolean status, PenguinFamily penguinFamily) {
        super(status, penguinFamily);
    }

    @Override
    public void updateKilledPenguinFamily() {

        int killedPossibility = killedPosibility();

        if (killedPossibility == 1)
            killMale(getPenguinFamily());
        else if (killedPossibility == 2)
            killFemale(getPenguinFamily());

        getPenguinFamily().updateChicksAndEggsBaseParents();

    }

    private int killedPosibility() {
        int posibility = 0;
        if (getDogNumber() == 0)
            posibility = getRandom(1, 10);
        else if (getDogNumber() == 1)
            posibility = getRandom(1, 8);
        else if (getDogNumber() == 2)
            posibility = getRandom(1, 6);

        return posibility;
    }

    private int getRandom(int min, int max) {
        return randomNumber.genRandom(min, max);
    }

    private boolean isPosibility() {
        int possibility = getRandom(1, 100);
        return possibility >= 1 && possibility <= 2;
    }

    private void killFemale(PenguinFamily penguinFamily) {
        if (!penguinFamily.isFemaleKilled() && isPosibility()) {
            penguinFamily.killFemale();
            setKilledFemalePenguinCount(getKilledFemalePenguinCount() + 1);
        }
    }

    private void killMale(PenguinFamily penguinFamily) {
        if (!penguinFamily.isMaleKilled() && isPosibility()) {
            penguinFamily.killMale();
            setKilledMalePenguinCount(getKilledMalePenguinCount() + 1);
        }
    }
}
