import java.util.Scanner;

public class Input {

    public String acceptStringInput(String displayMessage)
    {
        Scanner scanner = new Scanner(System.in);
        System.out.print(displayMessage);
        String input = scanner.nextLine();
        return input.trim();
    }

    public int acceptIntegerInput(String displayMessage)
    {
        Scanner scanner = new Scanner(System.in);
        System.out.println(displayMessage);
        int input = Integer.parseInt(scanner.nextLine().trim());
        return input;
    }

    public void acceptEnter(String message)
    {
        Scanner in = new Scanner(System.in);
        System.out.print(message);
        if (!in.hasNextLine()) {
            System.out.println(" Error invalid input ");
        }
    }

}
